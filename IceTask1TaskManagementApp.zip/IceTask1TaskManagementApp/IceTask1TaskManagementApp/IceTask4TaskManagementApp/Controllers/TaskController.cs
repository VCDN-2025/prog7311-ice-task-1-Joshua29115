﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

public class TaskController : Controller
{
    // Simulated in-memory task list
    private static List<TaskModel> _tasks = new List<TaskModel>();

    // Index: Display the list of tasks
    public IActionResult Index()
    {
        return View(_tasks);
    }

    // GET: Create a new task
    [HttpGet]
    public IActionResult Create()
    {
        return View();
    }

    // POST: Create a new task with validation
    [HttpPost]
    public IActionResult Create(TaskModel task)
    {
        if (ModelState.IsValid)
        {
            task.Id = _tasks.Count + 1;  // Simulate auto-incrementing ID
            _tasks.Add(task);
            return RedirectToAction("Index");
        }
        return View(task);  // If validation fails, show form with errors
    }

    // GET: Edit an existing task by ID
    [HttpGet]
    public IActionResult Edit(int id)
    {
        var task = _tasks.FirstOrDefault(t => t.Id == id);
        if (task == null)
        {
            return NotFound("Task not found");
        }
        return View(task);
    }

    // POST: Edit an existing task with validation
    [HttpPost]
    public IActionResult Edit(TaskModel updatedTask)
    {
        if (ModelState.IsValid)
        {
            var task = _tasks.FirstOrDefault(t => t.Id == updatedTask.Id);
            if (task != null)
            {
                task.Title = updatedTask.Title;
                task.Description = updatedTask.Description;
                task.Deadline = updatedTask.Deadline;
                return RedirectToAction("Index");
            }
            return NotFound("Task not found");
        }
        return View(updatedTask);
    }

    // GET: Confirm delete task by ID
    [HttpGet]
    public IActionResult Delete(int id)
    {
        var task = _tasks.FirstOrDefault(t => t.Id == id);
        if (task == null)
        {
            return NotFound("Task not found");
        }
        return View(task);
    }

    // POST: Delete a task
    [HttpPost, ActionName("Delete")]
    public IActionResult DeleteConfirmed(int id)
    {
        var task = _tasks.FirstOrDefault(t => t.Id == id);
        if (task != null)
        {
            _tasks.Remove(task);
            return RedirectToAction("Index");
        }
        return NotFound("Task not found");
    }
    //Mrzygłód, K., 2022. Azure for Developers. 2nd ed. August: [Meeta Rajani]

}
