﻿using System;
using System.ComponentModel.DataAnnotations;

public class TaskModel
{
    public int Id { get; set; }

    [Required(ErrorMessage = "The title is required.")]
    [MaxLength(100, ErrorMessage = "The title cannot be more than 100 characters long.")]
    public string Title { get; set; }

    [MaxLength(500, ErrorMessage = "The description cannot exceed 500 characters.")]
    public string Description { get; set; }

    [Required(ErrorMessage = "The deadline is required.")]
    [DataType(DataType.Date)]
    public DateTime Deadline { get; set; }
    //Mrzygłód, K., 2022. Azure for Developers. 2nd ed. August: [Meeta Rajani]

}
